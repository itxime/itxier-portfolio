import type { Dataset } from '../types/dataset.js';
import type { CleaningOptions, CleaningResult, DuplicateReviewResult, DuplicateRemovalPlan, KeepStrategy, CsvExport, ProcessingAdapter } from '../types/processing.js';
/** Selects prepared Python results only. No cleaning, browser APIs, or network I/O. */
export declare class SampleProcessingAdapter implements ProcessingAdapter {
    readonly supportedEmailColumns: readonly string[];
    readonly supportedHtmlColumns: readonly string[];
    readonly supportedMatchingColumns: readonly string[];
    constructor();
    get originalDataset(): Dataset;
    private selectState;
    exportDataset(dataset: Dataset): Promise<CsvExport>;
    process(options: CleaningOptions): Promise<CleaningResult>;
    private canonicalColumns;
    planDuplicateRemoval(options: CleaningOptions, matchingColumns: readonly string[], keep: KeepStrategy): Promise<DuplicateRemovalPlan>;
    reviewDuplicates(options: CleaningOptions, matchingColumns: readonly string[]): Promise<DuplicateReviewResult>;
}
