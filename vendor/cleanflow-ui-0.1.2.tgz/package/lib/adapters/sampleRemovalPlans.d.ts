import plans from '../data/removal-plans.json';
export default plans;
