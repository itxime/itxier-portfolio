import type { Dataset } from './dataset.js';
export interface CleaningOptions {
    readonly trimWhitespace: boolean;
    readonly normalizeEmail: boolean;
    readonly emailColumn: string | null;
    readonly cleanHtml: boolean;
    readonly htmlColumn: string | null;
}
export interface CleaningResult {
    readonly dataset: Dataset;
    readonly whitespaceChanges: number;
    readonly emailChanges: number;
    readonly htmlChanges: number;
    readonly totalModifiedCells: number;
}
export interface DuplicateReviewResult {
    readonly potentialDuplicateCount: number;
    /** Full cleaned rows with their original IDs; review never edits the dataset. */
    readonly matchingRows: Dataset;
}
export type KeepStrategy = 'first' | 'last';
export interface DuplicateRemovalPlan {
    readonly proposedRows: Dataset;
    readonly remainingRows: Dataset;
    readonly proposedRemovalCount: number;
    readonly remainingRowCount: number;
}
export interface CsvExport {
    readonly bytes: Uint8Array;
    readonly sha256: string;
    readonly filename: string;
    readonly mimeType: 'text/csv';
}
/** An adapter is bound to one source dataset; processing never edits that source. */
export interface ProcessingAdapter {
    readonly originalDataset: Dataset;
    readonly supportedEmailColumns: readonly string[];
    readonly supportedHtmlColumns: readonly string[];
    readonly supportedMatchingColumns: readonly string[];
    /** Export an exact supported final dataset; no filesystem paths or UI authorization. */
    exportDataset(dataset: Dataset): Promise<CsvExport>;
    /** Rejects unsupported configurations. Compatible with delayed local processing. */
    process(options: CleaningOptions): Promise<CleaningResult>;
    /** Preview only. Requires a nonempty set of supported, distinct matching columns. */
    planDuplicateRemoval(options: CleaningOptions, matchingColumns: readonly string[], keep: KeepStrategy): Promise<DuplicateRemovalPlan>;
    /** Matching columns form a set: order is equivalent; repeated/unknown columns reject. Empty means no review. */
    reviewDuplicates(options: CleaningOptions, matchingColumns: readonly string[]): Promise<DuplicateReviewResult>;
}
export declare class UnsupportedConfigurationError extends Error {
    constructor(message: string);
}
