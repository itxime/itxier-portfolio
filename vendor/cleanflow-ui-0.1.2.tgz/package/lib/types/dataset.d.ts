export interface DatasetRow {
    /** Original zero-based row position, retained when displaying derived data. */
    readonly id: number;
    readonly values: readonly (string | null)[];
}
export interface Dataset {
    readonly columns: readonly string[];
    readonly rows: readonly DatasetRow[];
}
