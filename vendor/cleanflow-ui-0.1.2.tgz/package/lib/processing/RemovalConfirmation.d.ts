import type { CleaningOptions, CleaningResult, DuplicateRemovalPlan, KeepStrategy } from '../types/processing.js';
export interface ConfirmationContext {
    readonly adapter: object;
    readonly sourceIdentity: string;
    readonly options: CleaningOptions;
    readonly matchingColumns: readonly string[];
    readonly processingRevision: CleaningResult | undefined;
    readonly failed: boolean;
}
/** In-memory UI authorization only. A future backend must validate independently. */
export declare class RemovalConfirmation {
    private context;
    private contextKey;
    private enabled;
    private keep;
    private plan;
    private approval;
    private counter;
    private planningStatus;
    get exportBlocked(): boolean;
    get revision(): number;
    synchronize(context: ConfirmationContext): void;
    configure(enabled: boolean, keep: KeepStrategy): void;
    revoke(): void;
    beginPlan(): number;
    failPlan(): void;
    receivePlan(revision: number, plan: DuplicateRemovalPlan): boolean;
    confirm(revision: number): boolean;
    get approvedPlan(): DuplicateRemovalPlan | undefined;
}
