/** Identifies the latest active invocation independently of option values. */
export declare class ProcessingRequests {
    private counter;
    private active;
    start(context: object): number;
    isCurrent(revision: number, context: object): boolean;
    cancel(revision: number): void;
}
