import type { ProcessingAdapter } from './types/processing.js';
import './App.css';
export interface CleanFlowDashboardProps {
    adapter?: ProcessingAdapter;
    /** Embedded by default. The standalone Vite host opts into its main landmark. */
    embedded?: boolean;
    theme?: 'light' | 'dark';
    /** Presentation-only notice for hosts running the fictional sample demonstration. */
    showDemoMessage?: boolean;
}
declare function App({ adapter, embedded, theme, showDemoMessage }: CleanFlowDashboardProps): import("react").JSX.Element;
export default App;
