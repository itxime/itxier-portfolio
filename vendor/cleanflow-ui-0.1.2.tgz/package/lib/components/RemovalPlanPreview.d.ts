import { RemovalConfirmation } from '../processing/RemovalConfirmation.js';
import type { CleaningOptions, CleaningResult, ProcessingAdapter } from '../types/processing.js';
interface Props {
    adapter: ProcessingAdapter;
    options: CleaningOptions | undefined;
    cleaned: CleaningResult | undefined;
    columns: readonly string[];
    confirmation?: RemovalConfirmation;
    onConfirmationChange?: () => void;
    reviewReady?: boolean;
}
/** Plans remain previews until one current proposal is explicitly approved. */
export declare function RemovalPlanPreview({ adapter, options, cleaned, columns, confirmation, onConfirmationChange, reviewReady }: Props): import("react").JSX.Element;
export {};
