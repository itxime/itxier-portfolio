import type { Dataset } from '../types/dataset.js';
import type { ProcessingAdapter } from '../types/processing.js';
interface Props {
    adapter: ProcessingAdapter;
    dataset: Dataset | undefined;
    revision: object;
}
/** Browser delivery only; all serialization happens in Python. */
export declare function CsvExportSection({ adapter, dataset, revision }: Props): import("react").JSX.Element;
export {};
