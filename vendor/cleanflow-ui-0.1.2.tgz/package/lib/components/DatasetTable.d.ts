import type { Dataset } from '../types/dataset.js';
interface DatasetTableProps {
    dataset: Dataset;
    title: string;
    description?: string;
}
export declare function DatasetTable({ dataset, title, description, }: DatasetTableProps): import("react").JSX.Element;
export {};
